global_var = 'global'

def scoper():
    # Your code here
    pass