from tools import double

def quadruple(n):
    # Your code here
    pass