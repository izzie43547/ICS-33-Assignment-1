def half(n):
    # Your code here
    pass

def describe_half(n):
    # Your code here
    pass