def double(n):
    # Your code here
    pass